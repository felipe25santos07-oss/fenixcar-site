Fenixcar - Site multi-página

Descompacte e envie para o GitHub (crie repositório e envie os arquivos) ou use GitHub web upload. Depois importe no Vercel (conectar ao repositório) para publicar.
